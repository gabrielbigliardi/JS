class AppRoutes {
  static const HOME = '/';
  static const USER_FORM = '/user-form';
}