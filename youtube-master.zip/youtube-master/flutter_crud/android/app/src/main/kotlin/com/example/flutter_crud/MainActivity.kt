package com.example.flutter_crud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
