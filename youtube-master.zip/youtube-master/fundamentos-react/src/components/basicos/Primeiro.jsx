import React from 'react'

export default () => 
    <>
        <h1>Primeiro Componente (Arrow)</h1>
        <h2>Exemplo de um componente React</h2>
    </>
    