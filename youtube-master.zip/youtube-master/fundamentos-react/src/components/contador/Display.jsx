import React from "react";

export default (props) => {
    
    return (
        <h4>Valor: {props.valor}</h4>
    );
};
