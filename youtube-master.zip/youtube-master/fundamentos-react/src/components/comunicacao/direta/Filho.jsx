import React from 'react'

export default props =>
    <div>
        <p>{props.children} {props.sobrenome}</p>
    </div>