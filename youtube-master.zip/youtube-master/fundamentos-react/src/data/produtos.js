export default [
    { id: 1, nome: 'Caneta', preco: 7.59 },
    { id: 2, nome: 'Lapis', preco: 3.89 },
    { id: 3, nome: 'Caderno', preco: 18.30 },
]