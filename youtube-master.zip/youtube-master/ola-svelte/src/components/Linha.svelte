<div class="linha">
    <slot />
</div>

<style>
    .linha {
        display: flex;
    }
</style>